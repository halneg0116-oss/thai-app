function convert() {
    let text = document.getElementById("inputText").value;

    fetch('/convert', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({text})
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById("output").innerText = data.thai;
    });
}
