# 超簡易版のローマ字→タイ文字変換（本格ロジックは後で追加可能）

consonants = {
    'k': 'ค','g': 'ก','s': 'ซ','z':'ซ','t':'ท','d':'ด',
    'n':'น','h':'ฮ','b':'บ','p':'ป','m':'ม','y':'ย',
    'r':'ร','w':'ว'
}

vowels = {
    'a': 'า', 
    'i': 'ิ',
    'u': 'ุ',
    'e': 'เ',  # 前に置く
    'o': 'โ',  # 前に置く
}

def convert_romaji_to_thai(text):
    text = text.lower()
    result = ""

    i = 0
    while i < len(text):
        c = text[i]
        if c in consonants:
            # 次の文字が母音の場合
            if i + 1 < len(text) and text[i+1] in vowels:
                v = text[i+1]
                if v in ['e', 'o']:
                    # 母音が前に来る
                    result += vowels[v] + consonants[c]
                else:
                    result += consonants[c] + vowels[v]
                i += 2
                continue
            else:
                result += consonants[c]
        i += 1

    return result if result else ""
