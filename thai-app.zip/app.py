from flask import Flask, request, jsonify, send_from_directory
from converter import convert_romaji_to_thai

app = Flask(__name__, static_folder="static")

@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/convert", methods=["POST"])
def convert():
    data = request.json
    text = data.get("text", "")
    result = convert_romaji_to_thai(text)
    return jsonify({"thai": result})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
